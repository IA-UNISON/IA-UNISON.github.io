#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
conecta4.py.py
------------

El juego de conecta 4

Este juego contiene una parte de la tarea 5, y otra parte
es la implementación desde 0 del juego de Otello.

"""
import busquedas_adversarios
import tkinter as tk

__author__ = 'juliowaissman'


class ConectaCuatro(busquedas_adversarios.JuegoSumaCero2T):
    def __init__(self):
        """
        Inicializa el juego, esto es: el número de columnas y
        renglones y el estado inicial del juego. Cuyas posiciones
        estan dadas como:

                        35  36  37  38  39  40  41
                        28  29  30  31  32  33  34
                        21  22  23  24  25  26  27
                        14  15  16  17  18  19  20
                         7   8   9  10  11  12  13
                         0   1   2   3   4   5   6
        """
        super().__init__(tuple([0 for _ in range(6 * 7)]))

    def jugadas_legales(self):
        """
        Las jugadas legales son las columnas donde se puede
        poner una ficha (0, ..., 6), si no está llena.
        """
        return [j for j in range(7) if self.x[35 + j] == 0]

    def terminal(self):
        # Vamos a checar que se colocó al menos una pieza
        if not self.historial:
            return None
        #Checamos si la última pieza colocada forma 4 en algun sentido
        p = self.historial[-1]
        # Vertical
        if p > 20 and all(self.x[p - i] == self.x[p] for i in [7, 14, 21]):
            return self.x[p]
        #Horizontal y diagonales    
        for i in range(4): 
            if (p - 3 + i) // 7 == (p + i) // 7:
                #horizontales
                if all(
                    self.x[p + i - 3 + j] == self.x[p] 
                    for j in range(4)
                ):
                    return self.x[p]
                #diagonales 
                if 2 < p // 7 + i < 6:
                    if (all((self.x[p + 6 * (i - 3 + j)] == self.x[p] 
                            for j in range(4))) or
                        all((self.x[p + 8 * (i - 3 + j)] == self.x[p] 
                            for j in range(4)))):
                        return self.x[p]
        # Ahora checamos si no se lleno el tabero
        if 0 not in self.x:
            return 0
        return None

    def hacer_jugada(self, jugada):
        for i in range(0, 40, 7):
            if self.x[i + jugada] == 0:
                self.x[i + jugada] = self.jugador
                self.historial.append(i + jugada)
                self.jugador *= -1
                return None

    def deshacer_jugada(self):
        pos = self.historial.pop()
        self.x[pos] = 0
        self.jugador *= -1
        return None

def utilidad_c4(x):
    """
    Calcula la utilidad de una posición del juego conecta 4
    para el jugador max (las fichas rojas, o el que empieza)

    @param x: Una lista con el estado del tablero

    @return: Un número entre -1 y 1 con la ganancia esperada

    Para probar solo busque el número de conecciones de las
    bolitas de mas arriba con su alrededor
    """
    cum = 0
    for i in range(7):
        for j in (35, 28, 21, 14, 7, 0):
            if x[i] != 0:
                if 0 < i < 6:
                    biases = (-6, -7, -8, -1, 1, 6, 8)
                elif i == 0:
                    biases = (-7, -8, 1, 8)
                else:
                    biases = (-6, -7, -1, 6)
                con = sum(x[i] for bias in biases
                          if i + bias >= 0 and x[i] == x[i + bias])
                cum += con / len(biases)
                break
    return cum / 42

class Conecta4GUI:
    def __init__(self, tmax=10, escala=1):

        # La tabla de transposición
        self.tr_ta = {}

        # Máximo tiempo de búsqueda
        self.tmax = tmax

        self.app = app = tk.Tk()
        self.app.title("Conecta Cuatro")
        self.L = L = int(escala) * 50

        tmpstr = "Escoge color, rojas empiezan"
        self.anuncio = tk.Message(app, bg='white', borderwidth=1,
                                  justify=tk.CENTER, text=tmpstr,
                                  width=7*L)
        self.anuncio.pack()

        barra = tk.Frame(app)
        barra.pack()
        botonR = tk.Button(barra, command=lambda x=True: self.jugar(x),
                           text='(re)iniciar con rojas', width=22)
        botonR.grid(column=0, row=0)
        botonN = tk.Button(barra, command=lambda x=False: self.jugar(x),
                           text='(re)iniciar con negras', width=22)
        botonN.grid(column=1, row=0)

        ctn = tk.Frame(app, bg='black')
        ctn.pack()

        self.sel_j = tk.IntVar(self.anuncio.master, -1, 'sel_j')

        def boton_f(fila):
            self.sel_j.set(fila)

        self.flecha = tk.PhotoImage(file='flecha2.gif')
        self.botones = [None for _ in range(7)]
        for i in range(7):
            self.botones[i] = tk.Button(ctn, image=self.flecha,
                                        command=lambda fila=i: boton_f(fila),
                                        width=L, height=L,
                                        state=tk.DISABLED)
            self.botones[i].grid(column=i, row=0)

        self.can = [None for _ in range(6 * 7)]
        self.cuadritos = [None for _ in range(6 * 7)]
        for i in range(6 * 7):
            self.can[i] = tk.Canvas(ctn, height=L, width=L,
                                    bg='light grey', borderwidth=0)
            self.can[i].grid(row=((41 - i) // 7) + 1, column=i % 7)
            self.cuadritos[i] = self.can[i].create_oval(5, 5, L, L,
                                                        fill='white', width=2)
            self.can[i].val = 0

    def jugar(self, primero):

        juego = ConectaCuatro()

        for i in range(42):
            if self.can[i].val != 0:
                self.can[i].itemconfigure(self.cuadritos[i], fill='white')
                self.can[i].val = 0
        color, color_p = 'red', 'black'

        if not primero:
            color, color_p = 'black', 'red'
            self.anuncio['text'] = "Ahora juega Python"
            self.anuncio.update()
            for i in range(7):
                self.botones[i]['state'] = tk.DISABLED

            jugada = busquedas_adversarios.minimax(
                juego, 
                dmax=6, 
                utilidad=utilidad_c4,
                ordena_jugadas=None
            )
            juego.hacer_jugada(jugada)
            self.actualiza_tablero(jugada, color_p)

        for _ in range(43):
            self.anuncio['text'] = "Te toca jugar"
            self.anuncio.update()
            for i in juego.jugadas_legales():
                self.botones[i]['state'] = tk.NORMAL

            self.anuncio.master.wait_variable('sel_j')
            jugada = self.sel_j.get()
            juego.hacer_jugada(jugada)
            self.actualiza_tablero(jugada, color)

            ganancia = juego.terminal()
            if ganancia is not None:
                break

            self.anuncio['text'] = "Ahora juega Python"
            self.anuncio.update()
            for i in range(7):
                self.botones[i]['state'] = tk.DISABLED
                self.botones[i].update()

            jugada = busquedas_adversarios.minimax(
                juego, 
                dmax=6, 
                utilidad=utilidad_c4, 
                ordena_jugadas=None
            )
            juego.hacer_jugada(jugada)
            self.actualiza_tablero(jugada, color_p)

            ganancia = juego.terminal()
            if ganancia is not None:
                break

        for i in range(7):
            self.botones[i]['state'] = tk.DISABLED

        str_fin = ("Ganaron las rojas" if ganancia > 0 else
                   "Ganaron las negars" if ganancia < 0 else
                   "Un asqueroso empate")
        self.anuncio['text'] = str_fin

    def actualiza_tablero(self, fila, color):
        for i in range(0, 41, 7):
            if self.can[i + fila].val == 0:
                self.can[i + fila].itemconfigure(self.cuadritos[i + fila],
                                                 fill=color)
                self.can[i + fila].val = 1 if color is 'red' else -1
                self.can[i + fila].update()
                break

    def arranca(self):
        self.app.mainloop()


if __name__ == '__main__':
    Conecta4GUI(tmax=10).arranca()
