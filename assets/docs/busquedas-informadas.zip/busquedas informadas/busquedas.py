#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
busquedas.py
------------

Clases y algoritmos necesarios para desarrollar agentes de
búsquedas en entornos determinísticos conocidos discretos
completamente observables

"""

__author__ = 'juliowaissman'

from collections import deque
import heapq


class ModeloBusqueda:
    """
    Clase genérica de un modelo de búsqueda.

    Todo modelo de búsqueda debe de tener:
        1) Un método que obtenga las acciones legales en cada estado
        2) Un método que calcule cual es es siguiente estado
        3) Una función de costo local

    """
    def acciones_legales(self, estado):
        """
        Lista de acciones legales en un estado dado.

        @param estado: Una tupla con un estado válido.

        @return: Una lista de acciones legales.

        """
        raise NotImplementedError("No implementado todavía.")

    def sucesor(self, estado, accion):
        """
        Estado sucesor

        @param estado: Una tupla con un estado válido.
        @param accion: Una acción legal en el estado.

        @return: Una tupla con el estado sucesor de estado cuando
                 se aplica la acción.

        """
        raise NotImplementedError("No implementado todavía.")

    def costo_local(self, estado, accion):
        """
        Calcula el costo de realizar una acción en un estado.

        @param estado: Una tupla con un estado válido.
        @param acción: Una acción legal en estado.

        @return: Un número positivo con el costo de realizar
                 la acción en el estado.

        """
        return 1


class ProblemaBusqueda:
    """
    Clase genérica de un problema de búsqueda.

    Todo problema de búsqueda debe de tener:
        a) Un estado inicial
        b) Una función que diga si un estado es una meta o no
        c) Un modelo para la búsqueda

    """
    def __init__(self, x0, meta, modelo):
        """
        Inicializa el problema de búsqueda

        @param x0: Una tupla con un estado válido del
                   problema (estado inicial).
        @param meta: Una función meta(s) --> bool,
                     donde meta(s) devuelve True solo
                     si el estado s es un estado objetivo.
        @param modelo: Un objeto de la clase ModeloBusqueda

        """
        def es_meta(estado):
            self.num_nodos += 1
            return meta(estado)
        self.es_meta = es_meta

        self.x0 = x0
        self.modelo = modelo
        self.num_nodos = 0  # Solo para efectos medición


class Nodo:
    """
    Clase para implementar un árbol como estructura de datos.

    """
    def __init__(self, estado, accion=None, padre=None, costo_local=0):
        """
        Inicializa un nodo como una estructura

        """
        self.estado = estado
        self.accion = accion
        self.padre = padre
        self.costo = 0 if not padre else padre.costo + costo_local
        self.profundidad = 0 if not padre else padre.profundidad + 1
        self.nodos_visitados = 0

    def expande(self, modelo):
        """
        Expande un nodo en todos sus nodos hijos de acuerdo al problema pb

        @param modelo: Un objeto de una clase heredada de ModeloBusqueda

        @return: Una lista de posibles nodos sucesores

        """
        return (
            Nodo(
                modelo.sucesor(self.estado, a),
                a,
                self,
                modelo.costo_local(self.estado, a))
            for a in modelo.acciones_legales(self.estado))

    def genera_plan(self):
        """
        Genera el plan (parcial o completo) que representa el nodo.

        @return: Una lista [x0, a1, x1, a2, x2, ..., aT, xT], donde
                 los x0, x1, ..., xT son tuplas con los estados a
                 cada paso del plan, mientras que los a1, a2, ..., aT
                 son las acciónes que hay que implementar para llegar desde
                 el estado inicial x0 hasta el testado final xT

        """
        return ([self.estado] if not self.padre else
                self.padre.genera_plan() + [self.accion, self.estado])

    def __str__(self):
        """
        Muestra el nodo como lo que es en realidad, un plan.

        """
        plan = self.genera_plan()
        return ("Costo: {}\n".format(self.costo) +
                "Profundidad: {}\n".format(self.profundidad) +
                "Trayectoria:\n" +
                "".join(["en {} hace {} y va a {},\n".format(x, a, xp)
                         for (x, a, xp)
                         in zip(plan[:-1:2], plan[1::2], plan[2::2])]))

    # Este método de sobrecarga del operador < es necesario
    # para poder utilizar los nodos en la heapq
    def __lt__(self, other):
        return self.costo < other.costo


def a_estrella(problema, heuristica):
    """
    Búsqueda por costo uniforme

    @param problema: Un objeto de una clase heredada de ProblemaBusqueda

    @return Un objeto tipo Nodo con la estructura completa

    """
    frontera = []
    heapq.heappush(frontera, (0, Nodo(problema.x0)))

    while frontera:
        (_, nodo) = heapq.heappop(frontera)
        if problema.es_meta(nodo.estado):
            nodo.nodos_visitados = problema.num_nodos
            return nodo
        for hijo in nodo.expande(problema.modelo):
            heapq.heappush(frontera, (hijo.costo + heuristica(hijo), hijo))
    return None

def a_estrella_grafo(problema, heuristica):
    """
    Búsqueda por costo uniforme

    @param problema: Un objeto de una clase heredada de ProblemaBusqueda

    @return Un objeto tipo Nodo con la estructura completa

    """
    frontera = []
    heapq.heappush(frontera, (0, Nodo(problema.x0)))
    visitados = set([])

    while frontera:
        (_, nodo) = heapq.heappop(frontera)
        if problema.es_meta(nodo.estado):
            nodo.nodos_visitados = problema.num_nodos
            return nodo
        visitados.add(nodo.estado)
        for hijo in nodo.expande(problema.modelo):
            if (hijo.estado not in visitados):
                heapq.heappush(frontera, (hijo.costo + heuristica(hijo), hijo))
    return None
